const express = require('express');
const app = express();
const number_of_bottles = [
  { id: 99, name: '99 bottles on the wall'},
  { id: 98, name: '98 bottles on the wall'},
  { id: 97, name: '97 bottles on the wall'},
];

app.get('/', (req, res) => {
  res.send("<h1>99 bottles on the wall</h1><a href='/98'>take one pass it around</a>")
});

app.get('/:number_of_bottles', (req, res) => {
  res.send(`<h1>${req.params.number_of_bottles} botlles of beer on the wall</h1><a href="${req.params.number_of_bottles -1}">take one down pass it around</a>`)
})


app.listen(3000, () => console.log('listening on port 3000....'));